# Sign Language Detection > 2024-05-05 10:01am
https://universe.roboflow.com/object-detection-vbiyz/sign-language-detection-gycvg

Provided by a Roboflow user
License: CC BY 4.0

